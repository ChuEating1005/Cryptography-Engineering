import random

for _ in range(10):
    random.seed(1000000)
    print(random.random())